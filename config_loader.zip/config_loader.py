# """
# Configuration Loader
# Loads API configurations from JSON file
# """

# import json
# import os
# from typing import Dict

# def load_config(config_path: str = "config.json") -> Dict:
#     """
#     Load configuration from JSON file
    
#     Args:
#         config_path: Path to configuration file
        
#     Returns:
#         Dictionary containing all configurations
#     """
#     try:
#         if not os.path.exists(config_path):
#             print(f"⚠️ Config file not found at {config_path}, using defaults...")
#             return get_default_config()
        
#         with open(config_path, 'r') as f:
#             config = json.load(f)
        
#         print(f"✅ Configuration loaded from {config_path}")
#         return config
        
#     except Exception as e:
#         print(f"❌ Error loading config: {str(e)}")
#         print("Using default configuration...")
#         return get_default_config()

# def get_default_config() -> Dict:
#     """
#     Return default configuration
#     Used when config file is not found
#     """
#     return {
#         "openai": {
#             "api_key": "sk-mock-key-for-demo",
#             "model": "gpt-4"
#         },
#         "hubspot": {
#             "api_key": "mock-hubspot-api-key",
#             "base_url": "https://api.hubapi.com"
#         },
#         "email": {
#             "smtp_server": "smtp.gmail.com",
#             "smtp_port": 587,
#             "sender_email": "ai-agent@demo.com",
#             "sender_password": "mock-password",
#             "recipient_email": "bilalkhanscc@gmail.com"
#         }
#     }

# def validate_config(config: Dict) -> bool:
#     """
#     Validate configuration structure
    
#     Args:
#         config: Configuration dictionary
        
#     Returns:
#         Boolean indicating if config is valid
#     """
#     required_keys = ["openai", "hubspot", "email"]
    
#     for key in required_keys:
#         if key not in config:
#             print(f"❌ Missing required config section: {key}")
#             return False
    
#     # Validate OpenAI config
#     if "api_key" not in config["openai"] or "model" not in config["openai"]:
#         print("❌ Invalid OpenAI configuration")
#         return False
    
#     # Validate HubSpot config
#     if "api_key" not in config["hubspot"]:
#         print("❌ Invalid HubSpot configuration")
#         return False
    
#     # Validate Email config
#     email_required = ["smtp_server", "smtp_port", "sender_email", "recipient_email"]
#     for key in email_required:
#         if key not in config["email"]:
#             print(f"❌ Missing email config: {key}")
#             return False
        
 
    
#     print("✅ Configuration validated successfully")
#     return True


"""
Configuration Loader
Loads API configurations from JSON file
"""

import json
import os
from typing import Dict

def load_config(config_path: str = "config.json") -> Dict:
    """
    Load configuration from JSON file
    
    Args:
        config_path: Path to configuration file
        
    Returns:
        Dictionary containing all configurations
    """
    try:
        if not os.path.exists(config_path):
            print(f"⚠️ Config file not found at {config_path}, using defaults...")
            return get_default_config()
        
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # For demo mode, ensure no real API key is required
        if "openai" in config:
            config["openai"].pop("api_key", None)  # Remove OpenAI API key if present
        
        print(f"✅ Configuration loaded from {config_path}")
        if validate_config(config):
            return config
        else:
            print("⚠️ Invalid config, falling back to defaults...")
            return get_default_config()
        
    except Exception as e:
        print(f"❌ Error loading config: {str(e)}")
        print("Using default configuration...")
        return get_default_config()

def get_default_config() -> Dict:
    """
    Return default configuration
    Used when config file is not found or invalid
    """
    return {
        "openai": {
            "model": "mock_model"  # Mock model name for demo
        },
        "hubspot": {
            "api_key": "mock-hubspot-api-key",
            "base_url": "https://api.hubapi.com"
        },
        "email": {
            "smtp_server": "smtp.gmail.com",
            "smtp_port": 587,
            "sender_email": "ai-agent@demo.com",
            "sender_password": "mock-password",
            "recipient_email": "bilalkhanscc@gmail.com"
        }
    }

def validate_config(config: Dict) -> bool:
    """
    Validate configuration structure for demo mode
    
    Args:
        config: Configuration dictionary
        
    Returns:
        Boolean indicating if config is valid
    """
    required_keys = ["openai", "hubspot", "email"]
    
    for key in required_keys:
        if key not in config:
            print(f"❌ Missing required config section: {key}")
            return False
    
    # Validate OpenAI config (no api_key needed for mock)
    if "model" not in config["openai"]:
        print("❌ Invalid OpenAI configuration: missing model")
        return False
    
    # Validate HubSpot config (mock key is fine)
    if "api_key" not in config["hubspot"] or "base_url" not in config["hubspot"]:
        print("❌ Invalid HubSpot configuration")
        return False
    
    # Validate Email config
    email_required = ["smtp_server", "smtp_port", "sender_email", "recipient_email"]
    for key in email_required:
        if key not in config["email"]:
            print(f"❌ Missing email config: {key}")
            return False
    
    print("✅ Configuration validated successfully")
    return True