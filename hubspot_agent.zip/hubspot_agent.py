# """
# HubSpot Agent - Handles CRM operations
# Supports: Create/Update Contacts, Create/Edit Deals
# """

# import json
# import re
# from typing import Dict, Any
# from langchain_openai import ChatOpenAI
# from langchain_core.tools import tool
# from langchain_core.messages import HumanMessage

# class HubSpotAgent:
#     def __init__(self, config: Dict):
#         """Initialize HubSpot Agent with configuration"""
#         self.config = config
#         self.api_key = config["hubspot"]["api_key"]
#         self.llm = ChatOpenAI(
#             model=config["openai"]["model"],
#             api_key=config["openai"]["api_key"],
#             temperature=0
#         )
        
#         # Bind CRM operation tools
#         self.tools = [
#             self.create_contact,
#             self.update_contact,
#             self.create_deal,
#             self.update_deal
#         ]
#         self.llm_with_tools = self.llm.bind_tools(self.tools)
    
#     @tool
#     def create_contact(firstname: str, lastname: str = "", email: str = "", phone: str = "", company: str = "") -> Dict:
#         """
#         Create a new contact in HubSpot CRM.
        
#         Args:
#             firstname: First name of the contact (required)
#             lastname: Last name of the contact
#             email: Email address
#             phone: Phone number
#             company: Company name
#         """
#         # Mock API call - In production, this would call actual HubSpot API
#         contact_data = {
#             "firstname": firstname,
#             "lastname": lastname,
#             "email": email,
#             "phone": phone,
#             "company": company
#         }
        
#         # Simulate API response
#         return {
#             "id": "mock_contact_12345",
#             "properties": contact_data,
#             "created": True
#         }
    
#     @tool
#     def update_contact(email: str, firstname: str = "", lastname: str = "", phone: str = "", company: str = "") -> Dict:
#         """
#         Update an existing contact in HubSpot CRM by email.
        
#         Args:
#             email: Email address of the contact to update (required)
#             firstname: Updated first name
#             lastname: Updated last name
#             phone: Updated phone number
#             company: Updated company name
#         """
#         # Mock API call
#         updated_fields = {k: v for k, v in {
#             "firstname": firstname,
#             "lastname": lastname,
#             "phone": phone,
#             "company": company
#         }.items() if v}
        
#         return {
#             "id": "mock_contact_67890",
#             "email": email,
#             "updated_properties": updated_fields,
#             "updated": True
#         }
    
#     @tool
#     def create_deal(dealname: str, amount: str, contact_email: str = "", pipeline: str = "default", dealstage: str = "appointmentscheduled") -> Dict:
#         """
#         Create a new deal in HubSpot CRM.
        
#         Args:
#             dealname: Name of the deal (required)
#             amount: Deal amount in dollars (required)
#             contact_email: Email of associated contact
#             pipeline: Sales pipeline (default: "default")
#             dealstage: Current stage of the deal
#         """
#         # Mock API call
#         deal_data = {
#             "dealname": dealname,
#             "amount": amount,
#             "contact_email": contact_email,
#             "pipeline": pipeline,
#             "dealstage": dealstage
#         }
        
#         return {
#             "id": "mock_deal_54321",
#             "properties": deal_data,
#             "created": True
#         }
    
#     @tool
#     def update_deal(deal_id: str, dealname: str = "", amount: str = "", dealstage: str = "") -> Dict:
#         """
#         Update an existing deal in HubSpot CRM.
        
#         Args:
#             deal_id: ID of the deal to update (required)
#             dealname: Updated deal name
#             amount: Updated deal amount
#             dealstage: Updated deal stage
#         """
#         # Mock API call
#         updated_fields = {k: v for k, v in {
#             "dealname": dealname,
#             "amount": amount,
#             "dealstage": dealstage
#         }.items() if v}
        
#         return {
#             "id": deal_id,
#             "updated_properties": updated_fields,
#             "updated": True
#         }
    
#     def process_query(self, query: str) -> Dict[str, Any]:
#         """
#         Process user query and execute appropriate CRM operation
        
#         Args:
#             query: Natural language query from user
            
#         Returns:
#             Dictionary containing operation results
#         """
#         print("\n🔄 HubSpot Agent Processing Query...")
        
#         try:
#             # Use LLM to understand intent and extract parameters
#             response = self.llm_with_tools.invoke([
#                 HumanMessage(content=f"""Analyze this CRM request and call the appropriate function:
                
# Query: {query}

# Instructions:
# - For creating contacts, extract firstname, lastname, email, phone, company
# - For updating contacts, identify the email and fields to update
# - For creating deals, extract dealname, amount, and associated contact email
# - For updating deals, extract deal_id and fields to update

# Call the appropriate function with the extracted parameters.""")
#             ])
            
#             # Execute the tool call
#             if hasattr(response, 'tool_calls') and response.tool_calls:
#                 tool_call = response.tool_calls[0]
#                 function_name = tool_call['name']
#                 function_args = tool_call['args']
                
#                 print(f"   └─ Operation: {function_name}")
#                 print(f"   └─ Parameters: {json.dumps(function_args, indent=6)}")
                
#                 # Execute the appropriate function
#                 if function_name == "create_contact":
#                     result = self.create_contact.invoke(function_args)
#                     operation_type = "Create Contact"
#                 elif function_name == "update_contact":
#                     result = self.update_contact.invoke(function_args)
#                     operation_type = "Update Contact"
#                 elif function_name == "create_deal":
#                     result = self.create_deal.invoke(function_args)
#                     operation_type = "Create Deal"
#                 elif function_name == "update_deal":
#                     result = self.update_deal.invoke(function_args)
#                     operation_type = "Update Deal"
#                 else:
#                     raise ValueError(f"Unknown operation: {function_name}")
                
#                 print(f"\n✅ HubSpot Operation Successful!")
                
#                 return {
#                     "operation": operation_type,
#                     "status": "success",
#                     "data": result,
#                     "query": query
#                 }
#             else:
#                 raise ValueError("Could not determine appropriate CRM operation")
                
#         except Exception as e:
#             print(f"\n❌ HubSpot Operation Failed: {str(e)}")
#             return {
#                 "operation": "Unknown",
#                 "status": "error",
#                 "error": str(e),
#                 "query": query
#             }
    
#     def _mock_api_call(self, endpoint: str, method: str, data: Dict) -> Dict:
#         """
#         Mock HubSpot API call for demonstration
#         In production, replace with actual API calls using requests library
#         """
#         # Simulate successful API response
#         return {
#             "status": "success",
#             "endpoint": endpoint,
#             "method": method,
#             "data": data,
#             "id": f"mock_{endpoint}_{hash(str(data)) % 100000}"
#         }

"""
HubSpot Agent - Handles CRM operations
Supports: Create/Update Contacts, Create/Edit Deals
"""

import json
from typing import Dict, Any
import re
class HubSpotAgent:
    def __init__(self, config: Dict):
        """Initialize HubSpot Agent with configuration"""
        self.config = config
        self.api_key = config["hubspot"].get("api_key", "mock-hubspot-api-key")
    
    def create_contact(self, firstname: str, lastname: str = "", email: str = "", phone: str = "", company: str = "") -> Dict:
        """
        Create a new contact in HubSpot CRM.
        
        Args:
            firstname: First name of the contact (required)
            lastname: Last name of the contact
            email: Email address
            phone: Phone number
            company: Company name
        """
        # Mock API call - In production, this would call actual HubSpot API
        contact_data = {
            "firstname": firstname,
            "lastname": lastname,
            "email": email,
            "phone": phone,
            "company": company
        }
        
        # Simulate API response
        return {
            "id": "mock_contact_12345",
            "properties": contact_data,
            "created": True
        }
    
    def update_contact(self, email: str, firstname: str = "", lastname: str = "", phone: str = "", company: str = "") -> Dict:
        """
        Update an existing contact in HubSpot CRM by email.
        
        Args:
            email: Email address of the contact to update (required)
            firstname: Updated first name
            lastname: Updated last name
            phone: Updated phone number
            company: Updated company name
        """
        # Mock API call
        updated_fields = {k: v for k, v in {
            "firstname": firstname,
            "lastname": lastname,
            "phone": phone,
            "company": company
        }.items() if v}
        
        return {
            "id": "mock_contact_67890",
            "email": email,
            "updated_properties": updated_fields,
            "updated": True
        }
    
    def create_deal(self, dealname: str, amount: str, contact_email: str = "", pipeline: str = "default", dealstage: str = "appointmentscheduled") -> Dict:
        """
        Create a new deal in HubSpot CRM.
        
        Args:
            dealname: Name of the deal (required)
            amount: Deal amount in dollars (required)
            contact_email: Email of associated contact
            pipeline: Sales pipeline (default: "default")
            dealstage: Current stage of the deal
        """
        # Mock API call
        deal_data = {
            "dealname": dealname,
            "amount": amount,
            "contact_email": contact_email,
            "pipeline": pipeline,
            "dealstage": dealstage
        }
        
        return {
            "id": "mock_deal_54321",
            "properties": deal_data,
            "created": True
        }
    
    def update_deal(self, deal_id: str, dealname: str = "", amount: str = "", dealstage: str = "") -> Dict:
        """
        Update an existing deal in HubSpot CRM.
        
        Args:
            deal_id: ID of the deal to update (required)
            dealname: Updated deal name
            amount: Updated deal amount
            dealstage: Updated deal stage
        """
        # Mock API call
        updated_fields = {k: v for k, v in {
            "dealname": dealname,
            "amount": amount,
            "dealstage": dealstage
        }.items() if v}
        
        return {
            "id": deal_id,
            "updated_properties": updated_fields,
            "updated": True
        }
    
    def process_query(self, query: str) -> Dict[str, Any]:
        """
        Process user query and execute appropriate CRM operation (MOCKED FOR DEMO)
        
        Args:
            query: Natural language query from user
            
        Returns:
            Dictionary containing operation results
        """
        print("\n🔄 HubSpot Agent Processing Query (Demo Mode)...")
        query_lower = query.lower()
        
        try:
            # Mock logic to select operation based on keywords
            if "create" in query_lower and "contact" in query_lower:
                # Extract parameters for create_contact
                firstname = "John" if "john" in query_lower else "Unknown"
                lastname = "Doe" if "doe" in query_lower else ""
                email_match = re.search(r'[\w\.-]+@[\w\.-]+', query)
                email = email_match.group(0) if email_match else "john.doe@example.com"
                phone_match = re.search(r'\+?\d[\d\s-]{8,}\d', query)
                phone = phone_match.group(0) if phone_match else ""
                company = "TechCorp" if "company" in query_lower else ""
                
                result = self.create_contact(firstname, lastname, email, phone, company)
                operation_type = "Create Contact"
            
            elif "update" in query_lower and "contact" in query_lower:
                # Extract parameters for update_contact
                email_match = re.search(r'[\w\.-]+@[\w\.-]+', query)
                email = email_match.group(0) if email_match else "jane@example.com"
                company = "TechCorp" if "company" in query_lower else ""
                
                result = self.update_contact(email, company=company)
                operation_type = "Update Contact"
            
            elif "create" in query_lower and "deal" in query_lower:
                # Extract parameters for create_deal
                dealname_match = re.search(r"deal named ['\"]([^'\"]+)['\"]", query, re.IGNORECASE)
                dealname = dealname_match.group(1) if dealname_match else "New Deal"
                amount_match = re.search(r'\$\d+', query)
                amount = amount_match.group(0).replace("$", "") if amount_match else "50000"
                email_match = re.search(r'[\w\.-]+@[\w\.-]+', query)
                contact_email = email_match.group(0) if email_match else ""
                
                result = self.create_deal(dealname, amount, contact_email)
                operation_type = "Create Deal"
            
            elif "update" in query_lower and "deal" in query_lower:
                # Extract parameters for update_deal
                deal_id = "mock_deal_54321"  # Hardcoded for demo
                dealname_match = re.search(r"deal named ['\"]([^'\"]+)['\"]", query, re.IGNORECASE)
                dealname = dealname_match.group(1) if dealname_match else ""
                
                result = self.update_deal(deal_id, dealname=dealname)
                operation_type = "Update Deal"
            
            else:
                raise ValueError("Could not determine appropriate CRM operation")
            
            print(f"   └─ Operation: {operation_type}")
            print(f"   └─ Result: {json.dumps(result, indent=2)}")
            print(f"\n✅ HubSpot Operation Successful!")
            
            return {
                "operation": operation_type,
                "status": "success",
                "data": result,
                "query": query
            }
                
        except Exception as e:
            print(f"\n❌ HubSpot Operation Failed: {str(e)}")
            return {
                "operation": "Unknown",
                "status": "error",
                "error": str(e),
                "query": query
            }