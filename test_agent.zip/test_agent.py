"""
Interactive Test Script for AI Agent System
Allows testing different queries easily
"""

from main import run_agent_system

def print_menu():
    """Display menu of test queries"""
    print("\n" + "="*60)
    print("AI AGENT SYSTEM - INTERACTIVE TEST")
    print("="*60)
    print("\nSelect a test query:")
    print("\n1. Create Contact - John Doe")
    print("2. Create Contact - Jane Smith")
    print("3. Update Contact - Change Company")
    print("4. Create Deal - Enterprise Package")
    print("5. Create Deal - Small Business Package")
    print("6. Update Deal - Change Status")
    print("7. Custom Query (enter your own)")
    print("0. Exit")
    print("\n" + "="*60)

def get_test_queries():
    """Return dictionary of pre-defined test queries"""
    return {
        "1": "Create a new contact named John Doe with email john.doe@example.com and phone +1234567890",
        "2": "Create a new contact named Jane Smith with email jane.smith@techcorp.com, phone +1987654321, and company TechCorp",
        "3": "Update contact with email john.doe@example.com to set company as InnovateLabs",
        "4": "Create a deal named 'Enterprise Package' worth $50000 for contact john.doe@example.com",
        "5": "Create a deal named 'Small Business Package' worth $5000 for contact jane.smith@techcorp.com",
        "6": "Update deal with ID deal_12345 to change amount to $75000 and stage to negotiation"
    }

def main():
    """Main interactive test loop"""
    print("\n🚀 Welcome to AI Agent System Testing Interface")
    
    queries = get_test_queries()
    
    while True:
        print_menu()
        choice = input("\nEnter your choice (0-7): ").strip()
        
        if choice == "0":
            print("\n👋 Thank you for testing! Goodbye.\n")
            break
        
        elif choice == "7":
            custom_query = input("\n📝 Enter your custom query: ").strip()
            if custom_query:
                run_agent_system(custom_query)
            else:
                print("❌ Query cannot be empty!")
        
        elif choice in queries:
            query = queries[choice]
            print(f"\n📋 Running: {query[:60]}...")
            run_agent_system(query)
            input("\n⏸️  Press Enter to continue...")
        
        else:
            print("\n❌ Invalid choice! Please select 0-7.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n👋 Interrupted by user. Goodbye!\n")
    except Exception as e:
        print(f"\n❌ Error: {str(e)}\n")