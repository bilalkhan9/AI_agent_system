# """
# Email Agent - Sends notification emails
# Confirms CRM operations via email
# """

# import json
# from typing import Dict, Any
# from datetime import datetime

# class EmailAgent:
#     def __init__(self, config: Dict):
#         """Initialize Email Agent with configuration"""
#         self.config = config
#         self.smtp_server = config["email"]["smtp_server"]
#         self.smtp_port = config["email"]["smtp_port"]
#         self.sender_email = config["email"]["sender_email"]
#         self.sender_password = config["email"]["sender_password"]
#         self.recipient_email = config["email"]["recipient_email"]
    
#     def send_confirmation(self, operation_result: Dict[str, Any]) -> bool:
#         """
#         Send confirmation email after CRM operation
        
#         Args:
#             operation_result: Dictionary containing operation details
            
#         Returns:
#             Boolean indicating success/failure
#         """
#         print("\n📧 Email Agent Sending Notification...")
        
#         try:
#             # Extract operation details
#             operation = operation_result.get("operation", "Unknown Operation")
#             status = operation_result.get("status", "unknown")
#             data = operation_result.get("data", {})
#             query = operation_result.get("query", "")
            
#             # Compose email
#             subject = f"✅ HubSpot CRM Operation Confirmed: {operation}"
#             body = self._compose_email_body(operation, status, data, query)
            
#             # Mock email sending (in production, use smtplib)
#             success = self._send_email_mock(
#                 recipient=self.recipient_email,
#                 subject=subject,
#                 body=body
#             )
            
#             if success:
#                 print(f"   └─ Email sent to: {self.recipient_email}")
#                 print(f"   └─ Subject: {subject}")
#                 print(f"\n✅ Email Notification Sent Successfully!")
#             else:
#                 print(f"\n⚠️ Email sending failed (mock mode)")
            
#             return success
            
#         except Exception as e:
#             print(f"\n❌ Email Agent Error: {str(e)}")
#             return False
    
#     def _compose_email_body(self, operation: str, status: str, data: Dict, query: str) -> str:
#         """Compose email body with operation details"""
#         timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
#         body = f"""
# HubSpot CRM Operation Confirmation
# {'='*50}

# Operation Type: {operation}
# Status: {status.upper()}
# Timestamp: {timestamp}

# Original Request:
# {query}

# Operation Details:
# {json.dumps(data, indent=2)}

# {'='*50}

# This is an automated notification from your AI Agent System.
# If you did not request this operation, please contact support.

# ---
# AI Agent System - Workflow Automation
# Powered by LangGraph & OpenAI
# """
#         return body
    
#     def _send_email_mock(self, recipient: str, subject: str, body: str) -> bool:
#         """
#         Mock email sending for demonstration
#         In production, replace with actual SMTP implementation
#         """
#         # Print email preview
#         print("\n" + "─"*60)
#         print("📧 EMAIL PREVIEW:")
#         print("─"*60)
#         print(f"To: {recipient}")
#         print(f"From: {self.sender_email}")
#         print(f"Subject: {subject}")
#         print("─"*60)
#         print(body)
#         print("─"*60)
        
#         # Simulate successful sending
#         return True
    
#     def _send_email_real(self, recipient: str, subject: str, body: str) -> bool:
#         """
#         Real email sending implementation using SMTP
#         Uncomment and configure for production use
#         """
#         """
#         import smtplib
#         from email.mime.text import MIMEText
#         from email.mime.multipart import MIMEMultipart
        
#         try:
#             # Create message
#             message = MIMEMultipart()
#             message["From"] = self.sender_email
#             message["To"] = recipient
#             message["Subject"] = subject
#             message.attach(MIMEText(body, "plain"))
            
#             # Connect to SMTP server
#             with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
#                 server.starttls()
#                 server.login(self.sender_email, self.sender_password)
#                 server.send_message(message)
            
#             return True
            
#         except Exception as e:
#             print(f"Error sending email: {str(e)}")
#             return False
#         """
#         pass

"""
Email Agent - Sends notification emails
Confirms CRM operations via email
"""

import json
from typing import Dict, Any
from datetime import datetime

class EmailAgent:
    def __init__(self, config: Dict):
        """Initialize Email Agent with configuration"""
        self.config = config
        # Safely access email config with defaults
        self.smtp_server = config["email"].get("smtp_server", "smtp.gmail.com")
        self.smtp_port = config["email"].get("smtp_port", 587)
        self.sender_email = config["email"].get("sender_email", "ai-agent@demo.com")
        self.sender_password = config["email"].get("sender_password", "mock-password")
        self.recipient_email = config["email"].get("recipient_email", "bilalkhanscc@gmail.com")
    
    def send_confirmation(self, operation_result: Dict[str, Any]) -> bool:
        """
        Send confirmation email after CRM operation (MOCKED FOR DEMO)
        
        Args:
            operation_result: Dictionary containing operation details
            
        Returns:
            Boolean indicating success/failure
        """
        print("\n📧 Email Agent Sending Notification (Demo Mode)...")
        
        try:
            # Extract operation details
            operation = operation_result.get("operation", "Unknown Operation")
            status = operation_result.get("status", "unknown")
            data = operation_result.get("data", {})
            query = operation_result.get("query", "")
            
            # Compose email
            subject = f"✅ HubSpot CRM Operation Confirmed: {operation}"
            body = self._compose_email_body(operation, status, data, query)
            
            # Mock email sending
            success = self._send_email_mock(
                recipient=self.recipient_email,
                subject=subject,
                body=body
            )
            
            if success:
                print(f"   └─ Email sent to: {self.recipient_email}")
                print(f"   └─ Subject: {subject}")
                print(f"\n✅ Email Notification Sent Successfully!")
            else:
                print(f"\n⚠️ Email sending failed (mock mode)")
            
            return success
            
        except Exception as e:
            print(f"\n❌ Email Agent Error: {str(e)}")
            return False
    
    def _compose_email_body(self, operation: str, status: str, data: Dict, query: str) -> str:
        """Compose email body with operation details"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        body = f"""
HubSpot CRM Operation Confirmation
{'='*50}

Operation Type: {operation}
Status: {status.upper()}
Timestamp: {timestamp}

Original Request:
{query}

Operation Details:
{json.dumps(data, indent=2)}

{'='*50}

This is an automated notification from your AI Agent System (Demo Mode).
If you did not request this operation, please contact support.

---
AI Agent System - Workflow Automation
"""
        return body
    
    def _send_email_mock(self, recipient: str, subject: str, body: str) -> bool:
        """
        Mock email sending for demonstration
        """
        # Print email preview
        print("\n" + "─"*60)
        print("📧 EMAIL PREVIEW (DEMO):")
        print("─"*60)
        print(f"To: {recipient}")
        print(f"From: {self.sender_email}")
        print(f"Subject: {subject}")
        print("─"*60)
        print(body)
        print("─"*60)
        
        # Simulate successful sending
        return True