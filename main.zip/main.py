"""
AI Agent System for HubSpot CRM Automation
Multi-Agent Architecture with Global Orchestrator
"""

import json
import os
from typing import TypedDict, Annotated, Sequence
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, FunctionMessage
from langchain_core.messages import AIMessage
from langchain_openai import ChatOpenAI
from langgraph.graph import StateGraph, END
#from langgraph.prebuilt import ToolNode
from langgraph.prebuilt.tool_node import ToolNode
from langchain_core.tools import tool
from hubspot_agent import HubSpotAgent
from email_agent import EmailAgent
from config_loader import load_config

# Load configuration
config = load_config()

# Initialize sub-agents
hubspot_agent = HubSpotAgent(config)
email_agent = EmailAgent(config)

# Define the agent state
class AgentState(TypedDict):
    messages: Annotated[Sequence[BaseMessage], "The messages in the conversation"]
    next_agent: str
    operation_result: dict

# Define tools for the orchestrator
@tool
def route_to_hubspot(query: str) -> str:
    """
    Route the query to HubSpot agent for CRM operations.
    Use this when user wants to create/update contacts or deals.
    
    Args:
        query: The user's request regarding HubSpot operations
    """
    return f"Routing to HubSpot agent: {query}"

@tool
def route_to_email(recipient: str, subject: str, body: str) -> str:
    """
    Route to Email agent to send notification emails.
    
    Args:
        recipient: Email address of the recipient
        subject: Email subject line
        body: Email body content
    """
    return f"Routing to Email agent for {recipient}"

# Initialize the LLM
# llm = ChatOpenAI(
#     model=config["openai"]["model"],
#     api_key=config["openai"]["api_key"],
#     temperature=0
# )

# # Bind tools to LLM
# tools = [route_to_hubspot, route_to_email]
# llm_with_tools = llm.bind_tools(tools)

# Define agent nodes
def orchestrator_node(state: AgentState) -> AgentState:
    """Global Orchestrator - Analyzes query and delegates to appropriate agent (MOCKED FOR DEMO)"""
    messages = state["messages"]
    user_query = messages[0].content.lower()  # Get the user query and make it lowercase for easier matching
    
    # Mock tool call logic based on keywords (simulate what the real model would do)
    mock_tool_call = None
    if "contact" in user_query or "deal" in user_query:
        # Simulate routing to HubSpot for CRM-related queries
        mock_tool_call = {
            "name": "route_to_hubspot",
            "args": {"query": user_query},
            "id": "mock_tool_call_id"  # Fake ID, not used but required for structure
        }
        state["next_agent"] = "hubspot"
    elif "email" in user_query:
        # Simulate routing to Email for email-related queries
        mock_tool_call = {
            "name": "route_to_email",
            "args": {"recipient": "example@example.com", "subject": "Mock Email", "body": user_query},
            "id": "mock_tool_call_id"
        }
        state["next_agent"] = "email"
    else:
        # Default: No routing, end the workflow
        state["next_agent"] = "end"
    
    # Create a mock AIMessage to simulate the model's response
    response = AIMessage(
        content=f"Mock response from orchestrator: Routed based on query '{user_query}'",
        tool_calls=[mock_tool_call] if mock_tool_call else []
    )
    
    return {
        **state,
        "messages": messages + [response]
    }

def hubspot_node(state: AgentState) -> AgentState:
    """HubSpot Agent - Handles CRM operations"""
    messages = state["messages"]
    user_query = messages[0].content
    
    # Process the query with HubSpot agent
    result = hubspot_agent.process_query(user_query)
    
    state["operation_result"] = result
    state["next_agent"] = "email"
    
    return state

def email_node(state: AgentState) -> AgentState:
    """Email Agent - Sends confirmation notifications"""
    operation_result = state.get("operation_result", {})
    
    # Send confirmation email
    email_result = email_agent.send_confirmation(operation_result)
    
    state["operation_result"]["email_sent"] = email_result
    state["next_agent"] = "end"
    
    return state

# Define routing logic
def route_agent(state: AgentState) -> str:
    """Determine the next agent to call"""
    next_agent = state.get("next_agent", "end")
    
    if next_agent == "hubspot":
        return "hubspot"
    elif next_agent == "email":
        return "email"
    else:
        return "end"

# Build the graph
def create_agent_graph():
    """Create the LangGraph workflow"""
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("orchestrator", orchestrator_node)
    workflow.add_node("hubspot", hubspot_node)
    workflow.add_node("email", email_node)
    
    # Add edges
    workflow.set_entry_point("orchestrator")
    workflow.add_conditional_edges(
        "orchestrator",
        route_agent,
        {
            "hubspot": "hubspot",
            "email": "email",
            "end": END
        }
    )
    workflow.add_edge("hubspot", "email")
    workflow.add_edge("email", END)
    
    return workflow.compile()

# Main execution
def run_agent_system(user_query: str):
    """
    Main function to run the multi-agent system
    
    Args:
        user_query: User's request for CRM operations
    """
    print("\n" + "="*60)
    print("AI AGENT SYSTEM - WORKFLOW AUTOMATION")
    print("="*60)
    print(f"\n📝 User Query: {user_query}\n")
    
    # Create and run the graph
    graph = create_agent_graph()
    
    initial_state = {
        "messages": [HumanMessage(content=user_query)],
        "next_agent": "",
        "operation_result": {}
    }
    
    # Execute the workflow
    result = graph.invoke(initial_state)
    
    # Display results
    print("\n" + "-"*60)
    print("📊 OPERATION RESULTS:")
    print("-"*60)
    
    operation_result = result.get("operation_result", {})
    
    if operation_result:
        print(f"\n✅ Operation: {operation_result.get('operation', 'N/A')}")
        print(f"📋 Status: {operation_result.get('status', 'N/A')}")
        print(f"🔍 Details: {json.dumps(operation_result.get('data', {}), indent=2)}")
        print(f"📧 Email Sent: {operation_result.get('email_sent', False)}")
    
    print("\n" + "="*60 + "\n")
    
    return result

if __name__ == "__main__":
    # Example queries to test
    test_queries = [
        "Create a new contact named John Doe with email john.doe@example.com and phone +1234567890",
        "Update contact with email jane@example.com to set company as TechCorp",
        "Create a deal named 'Enterprise Package' worth $50000 for contact john.doe@example.com"
    ]
    
    print("\n🚀 Starting AI Agent System Demo...\n")
    
    # Run with first example query
    run_agent_system(test_queries[0])
    
    # Uncomment to test other queries:
    # for query in test_queries[1:]:
    #     input("\nPress Enter to run next query...")
    #     run_agent_system(query)