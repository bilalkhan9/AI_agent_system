"""
Setup Script for AI Agent System
Automates the setup process
"""

import os
import sys
import subprocess
import json

def print_header(text):
    """Print formatted header"""
    print("\n" + "="*60)
    print(text.center(60))
    print("="*60 + "\n")

def check_python_version():
    """Check if Python version is compatible"""
    print("🔍 Checking Python version...")
    version = sys.version_info
    if version.major < 3 or (version.major == 3 and version.minor < 8):
        print(f"❌ Python 3.8+ required. You have {version.major}.{version.minor}")
        return False
    print(f"✅ Python {version.major}.{version.minor} detected")
    return True

def create_virtual_environment():
    """Create virtual environment"""
    print("\n🏗️  Creating virtual environment...")
    try:
        subprocess.run([sys.executable, "-m", "venv", "venv"], check=True)
        print("✅ Virtual environment created")
        return True
    except subprocess.CalledProcessError:
        print("❌ Failed to create virtual environment")
        return False

def get_pip_command():
    """Get the correct pip command based on OS"""
    if os.name == 'nt':  # Windows
        return os.path.join("venv", "Scripts", "pip.exe")
    else:  # macOS/Linux
        return os.path.join("venv", "bin", "pip")

def install_dependencies():
    """Install required packages"""
    print("\n📦 Installing dependencies...")
    pip_cmd = get_pip_command()
    
    try:
        subprocess.run([pip_cmd, "install", "-r", "requirements.txt"], check=True)
        print("✅ Dependencies installed successfully")
        return True
    except subprocess.CalledProcessError:
        print("❌ Failed to install dependencies")
        return False

def create_config_file():
    """Create config.json if it doesn't exist"""
    print("\n⚙️  Setting up configuration...")
    
    if os.path.exists("config.json"):
        print("✅ config.json already exists")
        return True
    
    config = {
        "openai": {
            "api_key": "sk-mock-key-for-demo",
            "model": "gpt-4"
        },
        "hubspot": {
            "api_key": "mock-hubspot-api-key",
            "base_url": "https://api.hubapi.com"
        },
        "email": {
            "smtp_server": "smtp.gmail.com",
            "smtp_port": 587,
            "sender_email": "ai-agent@demo.com",
            "sender_password": "mock-password",
            "recipient_email": "bilalkhanscc@gmail.com"
        }
    }
    
    try:
        with open("config.json", "w") as f:
            json.dump(config, f, indent=2)
        print("✅ config.json created with demo settings")
        print("⚠️  Remember to add your real API keys before production use!")
        return True
    except Exception as e:
        print(f"❌ Failed to create config.json: {str(e)}")
        return False

def print_next_steps():
    """Print instructions for next steps"""
    print_header("SETUP COMPLETE!")
    
    print("📋 Next Steps:\n")
    print("1. Activate the virtual environment:")
    if os.name == 'nt':  # Windows
        print("   venv\\Scripts\\activate")
    else:  # macOS/Linux
        print("   source venv/bin/activate")
    
    print("\n2. (Optional) Add your API keys to config.json")
    print("   - OpenAI API key")
    print("   - HubSpot API key")
    print("   - Email credentials")
    
    print("\n3. Run the test script:")
    print("   python test_agent.py")
    
    print("\n   OR run the main script:")
    print("   python main.py")
    
    print("\n" + "="*60)
    print("🎉 You're all set! Happy testing!")
    print("="*60 + "\n")

def main():
    """Main setup function"""
    print_header("AI AGENT SYSTEM - SETUP")
    
    # Check Python version
    if not check_python_version():
        sys.exit(1)
    
    # Create virtual environment
    if not create_virtual_environment():
        print("\n⚠️  You can skip this and use your system Python")
    
    # Install dependencies
    if not install_dependencies():
        print("\n❌ Setup failed. Please install dependencies manually.")
        sys.exit(1)
    
    # Create config file
    create_config_file()
    
    # Print next steps
    print_next_steps()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n❌ Setup interrupted by user.\n")
    except Exception as e:
        print(f"\n❌ Setup error: {str(e)}\n")